<?php
/*
$Id: texle.php,v 1.00 2019/04/21 10:56:45 hpdl Exp $

osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com

Copyright (c) 2014 osCommerce

*/

define('MODULE_PAYMENT_TREXLE_TEXT_TITLE', 'Trexle');
define('MODULE_PAYMENT_TREXLE_TEXT_DESCRIPTION', 'Trexle Payments');

define('MODULE_PAYMENT_TREXLE_CREDIT_CARD_OWNER_FIRSTNAME', 'Card Owner First Name:');
define('MODULE_PAYMENT_TREXLE_CREDIT_CARD_OWNER_LASTNAME', 'Card Owner Last Name:');
define('MODULE_PAYMENT_TREXLE_CREDIT_CARD_NUMBER', 'Card Number:');
define('MODULE_PAYMENT_TREXLE_CREDIT_CARD_EXPIRES', 'Card Expiry Date:');
define('MODULE_PAYMENT_TREXLE_CREDIT_CARD_CCV', 'Card Code Number (CCV):');

define('MODULE_PAYMENT_TREXLE_ERROR_ADMIN_CURL', 'This module requires cURL to be enabled in PHP and will not load until it has been enabled on this webserver.');
define('MODULE_PAYMENT_TREXLE_ERROR_ADMIN_CONFIGURATION', 'This module will not load until the API Key parameter have been configured. Please edit and configure the settings of this module.');

define('MODULE_PAYMENT_TREXLE_ERROR_TITLE', 'There has been an error processing your credit card');
define('MODULE_PAYMENT_TREXLE_ERROR_GENERAL', 'Please try again and if problems persist, please try another payment method.');

?>
<?php
/*
$Id: texle.php,v 1.00 2019/04/21 10:56:45 hpdl Exp $

osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com

Copyright (c) 2019 osCommerce

*/

class trexle
{
    var $code, $title, $description, $enabled;

    function trexle()
    {
        global $order;

        $this->code = 'trexle';
        $this->signature = 'trexle|trexle|1.0|1.0';
        $this->title = MODULE_PAYMENT_TREXLE_TEXT_TITLE;
        $this->description = MODULE_PAYMENT_TREXLE_TEXT_DESCRIPTION;/**/
        $this->sort_order = MODULE_PAYMENT_TREXLE_SORT_ORDER;
        $this->enabled = ((MODULE_PAYMENT_TREXLE_STATUS == 'True') ? true : false);


        if ((int)MODULE_PAYMENT_TREXLE_ORDER_STATUS_ID > 0) {
            $this->order_status = MODULE_PAYMENT_TREXLE_ORDER_STATUS_ID;
        }

        if (defined('MODULE_PAYMENT_TREXLE_ORDER_STATUS_ID')) {
            if (MODULE_PAYMENT_TREXLE_TRANSACTION_MODE == 'Test') {
                $this->title .= ' [Sandbox]';
            }
        }

        if (!function_exists('curl_init')) {
            $this->description = '<div class="secWarning">' . MODULE_PAYMENT_TREXLE_ERROR_ADMIN_CURL . '</div>' . $this->description;
            $this->enabled = false;
        }

        if ($this->enabled === true) {
            if (!tep_not_null(MODULE_PAYMENT_TREXLE_ERROR_ADMIN_CONFIGURATION)) {
                $this->description = '<div class="secWarning">' . MODULE_PAYMENT_TREXLE_ERROR_ADMIN_CONFIGURATION . '</div>' . $this->description;
                $this->enabled = false;
            }
        }

        if (is_object($order)) $this->update_status();

    }

    function update_status()
    {
        global $order;

        if (($this->enabled == true) && ((int)MODULE_PAYMENT_TREXLE_ZONE > 0)) {
            $check_flag = false;
            $check_query = tep_db_query("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_TREXLE_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
            while ($check = tep_db_fetch_array($check_query)) {
                if ($check['zone_id'] < 1) {
                    $check_flag = true;
                    break;
                } elseif ($check['zone_id'] == $order->billing['zone_id']) {
                    $check_flag = true;
                    break;
                }
            }

            if ($check_flag == false) {
                $this->enabled = false;
            }
        }
    }

    function javascript_validation()
    {
        return false;
    }

    function selection()
    {
        return array('id' => $this->code,
            'module' => $this->title);
    }

    function pre_confirmation_check()
    {
        return false;
    }

    function confirmation()
    {
        global $order;

        for ($i = 1; $i < 13; $i++) {
            $expires_month[] = array('id' => sprintf('%02d', $i), 'text' => sprintf('%02d', $i));
        }

        $today = getdate();
        for ($i = $today['year']; $i < $today['year'] + 10; $i++) {
            $expires_year[] = array('id' => strftime('%y', mktime(0, 0, 0, 1, 1, $i)), 'text' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)));
        }

        $confirmation = array('fields' =>
            array(
                array(
                    'title' => MODULE_PAYMENT_TREXLE_CREDIT_CARD_OWNER_FIRSTNAME,
                    'field' => tep_draw_input_field('cc_owner_firstname', $order->billing['firstname'])
                ),
                array(
                    'title' => MODULE_PAYMENT_TREXLE_CREDIT_CARD_OWNER_LASTNAME,
                    'field' => tep_draw_input_field('cc_owner_lastname', $order->billing['lastname'])
                ),
                array(
                    'title' => MODULE_PAYMENT_TREXLE_CREDIT_CARD_NUMBER,
                    'field' => tep_draw_input_field('cc_number_nh-dns')
                ),
                array(
                    'title' => MODULE_PAYMENT_TREXLE_CREDIT_CARD_EXPIRES,
                    'field' => tep_draw_pull_down_menu('cc_expires_month', $expires_month) . '&nbsp;' . tep_draw_pull_down_menu('cc_expires_year', $expires_year)
                ),
                array(
                    'title' => MODULE_PAYMENT_TREXLE_CREDIT_CARD_CCV,
                    'field' => tep_draw_input_field('cc_ccv_nh-dns', '', 'size="5" maxlength="4"')
                )
            )
        );

        return $confirmation;
    }

    function process_button()
    {
        return false;
    }

    function before_process()
    {
        global $HTTP_POST_VARS, $customer_id, $order, $sendto, $currency, $response;

        $data = [
            "amount" => substr($this->format_raw($order->info['total'], '', 100), 0, 15),
            "currency" => substr($currency, 0, 3),
            "description" => substr(STORE_NAME, 0, 255),
            "email" => substr($order->customer['email_address'], 0, 255),
            "ip_address" => tep_get_ip_address(),
            "card[number]" => substr(preg_replace('/[^0-9]/', '', $HTTP_POST_VARS['cc_number_nh-dns']), 0, 22),
            "card[expiry_month]" => $HTTP_POST_VARS['cc_expires_month'],
            "card[expiry_year]" => $HTTP_POST_VARS['cc_expires_year'],
            "card[cvc]" => substr($HTTP_POST_VARS['cc_ccv_nh-dns'], 0, 4),
            "card[name]" => trim($order->billing['firstname'] . " " . $order->billing['lastname']),
            "card[address_line1]" => substr($order->billing['street_address'], 0, 60),
            "card[address_line2]" => ' ',
            "card[address_city]" => substr($order->billing['city'], 0, 40),
            "card[address_postcode]" => substr($order->billing['postcode'], 0, 20),
            "card[address_state]" => substr($order->billing['state'], 0, 40),
            "card[address_country]" => substr($order->billing['country']['iso_code_3'], 0, 60),
            "capture" => ((MODULE_PAYMENT_TREXLE_TRANSACTION_METHOD == 'Capture') ? true : false)
        ];

        if (MODULE_PAYMENT_TREXLE_TRANSACTION_METHOD == 'Live') {
            $gateway_url = 'https://core.trexle.com/api/v1/charges';
        } else {
            $gateway_url = 'https://core.trexle.com/api/v1/charges';
        }

        $transaction_response = $this->sendTransactionToGateway($gateway_url, $data);
        $error = false;

        if (isset($transaction_response['error'])) {
            $error = 'declined';
        }

        if ($error !== false) {
            setcookie("error_title", 'error_' . $transaction_response['error']);
            setcookie("error_detail", 'error_' . $transaction_response['detail']);
            tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, 'payment_error=' . $this->code . '&error=' . $error, 'SSL'));
        }

        $response = $transaction_response['response'];
    }

    function after_process()
    {
        global $response, $order, $insert_id;

        $status[] = 'Transaction ID: ' . tep_db_prepare_input($response['token']);
        $status[] = 'Success: ' . tep_db_prepare_input($response['success']);
        $status[] = 'Captured: ' . tep_db_prepare_input($response['captured']);

        $sql_data_array = array(
            'orders_id' => $insert_id,
            'orders_status_id' => MODULE_PAYMENT_TREXLE_TRANSACTION_ORDER_STATUS_ID,
            'date_added' => 'now()',
            'customer_notified' => '0',
            'comments' => implode("\n", $status)
        );

        tep_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
        tep_db_query("update " . TABLE_ORDERS . " set orders_status = '" . (MODULE_PAYMENT_TREXLE_TRANSACTION_ORDER_STATUS_ID > 0 ? (int)MODULE_PAYMENT_TREXLE_TRANSACTION_ORDER_STATUS_ID : (int)DEFAULT_ORDERS_STATUS_ID) . "', last_modified = now() where orders_id = '" . $insert_id . "'");
    }

    function get_error()
    {
        global $HTTP_GET_VARS;

        $error_title = MODULE_PAYMENT_TREXLE_ERROR_TITLE;
        $error_message = MODULE_PAYMENT_TREXLE_ERROR_GENERAL;

        if ((isset($_COOKIE['error_title'])) && (isset($_COOKIE['error_detail']))) {
            $error_title = substr($_COOKIE['error_title'], 6);
            $error_message = substr($_COOKIE['error_detail'], 6);

            unset($_COOKIE['error_title']);
            unset($_COOKIE['error_detail']);
        }

        $error = array(
            'title' => $error_title,
            'error' => $error_message
        );

        return $error;
    }

    function check()
    {
        if (!isset($this->_check)) {
            $check_query = tep_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_TREXLE_STATUS'");
            $this->_check = tep_db_num_rows($check_query);
        }
        return $this->_check;
    }

    function install()
    {
        foreach ($this->getParams() as $key => $data) {
            $sql_data_array = array('configuration_title' => $data['title'],
                'configuration_key' => $key,
                'configuration_value' => (isset($data['value']) ? $data['value'] : ''),
                'configuration_description' => $data['desc'],
                'configuration_group_id' => '6',
                'sort_order' => '0',
                'date_added' => 'now()');

            if (isset($data['set_func'])) {
                $sql_data_array['set_function'] = $data['set_func'];
            }

            if (isset($data['use_func'])) {
                $sql_data_array['use_function'] = $data['use_func'];
            }

            tep_db_perform(TABLE_CONFIGURATION, $sql_data_array);
        }
    }

    function remove()
    {
        tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function getParams()
    {
        if (!defined('MODULE_PAYMENT_TREXLE_TRANSACTION_ORDER_STATUS_ID')) {
            $check_query = tep_db_query("select orders_status_id from " . TABLE_ORDERS_STATUS . " where orders_status_name = 'Trexle Payments' limit 1");

            if (tep_db_num_rows($check_query) < 1) {
                $status_query = tep_db_query("select max(orders_status_id) as status_id from " . TABLE_ORDERS_STATUS);
                $status = tep_db_fetch_array($status_query);

                $status_id = $status['status_id'] + 1;

                $languages = tep_get_languages();

                foreach ($languages as $lang) {
                    tep_db_query("insert into " . TABLE_ORDERS_STATUS . " (orders_status_id, language_id, orders_status_name) values ('" . $status_id . "', '" . $lang['id'] . "', 'Trexle Payments')");
                }

                $flags_query = tep_db_query("describe " . TABLE_ORDERS_STATUS . " public_flag");
                if (tep_db_num_rows($flags_query) == 1) {
                    tep_db_query("update " . TABLE_ORDERS_STATUS . " set public_flag = 0 and downloads_flag = 0 where orders_status_id = '" . $status_id . "'");
                }
            } else {
                $check = tep_db_fetch_array($check_query);

                $status_id = $check['orders_status_id'];
            }
        } else {
            $status_id = MODULE_PAYMENT_TREXLE_TRANSACTION_ORDER_STATUS_ID;
        }

        $params = array(
            'MODULE_PAYMENT_TREXLE_STATUS' =>
                array(
                    'title' => 'Enable Trexle Payments',
                    'desc' => 'Do you want to accept Trexle Method payments?',
                    'value' => 'True',
                    'set_func' => 'tep_cfg_select_option(array(\'True\', \'False\'), '
                ),
            'MODULE_PAYMENT_TREXLE_SECRET' =>
                array(
                    'title' => 'API Secret',
                    'desc' => 'Api key provided by Trexle'
                ),
            'MODULE_PAYMENT_TREXLE_TRANSACTION_METHOD' =>
                array(
                    'title' => 'Transaction Method',
                    'desc' => 'The processing method to use for each transaction.',
                    'value' => 'Capture',
                    'set_func' => 'tep_cfg_select_option(array(\'Capture\'), '
                ),
            'MODULE_PAYMENT_TREXLE_TRANSACTION_MODE' =>
                array(
                    'title' => 'Transaction Mode',
                    'desc' => 'Transaction mode used for processing orders',
                    'value' => 'Live',
                    'set_func' => 'tep_cfg_select_option(array(\'Live\', \'Test\'), '
                ),
            'MODULE_PAYMENT_TREXLE_TRANSACTION_ORDER_STATUS_ID' =>
                array(
                    'title' => 'Transaction Order Status',
                    'desc' => 'Include transaction information in this order status level',
                    'value' => $status_id,
                    'use_func' => 'tep_get_order_status_name',
                    'set_func' => 'tep_cfg_pull_down_order_statuses('
                ),
            'MODULE_PAYMENT_TREXLE_SORT_ORDER' =>
                array(
                    'title' => 'Sort order of display.',
                    'desc' => 'Sort order of display. Lowest is displayed first.',
                    'value' => '0'));

        return $params;
    }

    function keys()
    {
        return array('MODULE_PAYMENT_TREXLE_STATUS', 'MODULE_PAYMENT_TREXLE_SECRET', 'MODULE_PAYMENT_TREXLE_TRANSACTION_METHOD', 'MODULE_PAYMENT_TREXLE_TRANSACTION_MODE', 'MODULE_PAYMENT_TREXLE_TRANSACTION_ORDER_STATUS_ID', 'MODULE_PAYMENT_TREXLE_SORT_ORDER');
    }

    function format_raw($number, $reverse = false)
    {
        if ($reverse) {
            return number_format($number / 100, 2, '.', '');
        }
        return (int)$number * 100;
    }

    function sendTransactionToGateway($url, $parameters)
    {

        $curl = curl_init($url);

        curl_setopt($curl, CURLOPT_USERPWD, MODULE_PAYMENT_TREXLE_SECRET . ':');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $parameters);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Accept: application/json'));

        $result = curl_exec($curl);

        if (!curl_errno($curl)) {
            $info = curl_getinfo($curl);
            $result = json_decode($result, true);
            $result['http_code'] = $info['http_code'];
        }

        curl_close($curl);
        return $result;
    }
}
